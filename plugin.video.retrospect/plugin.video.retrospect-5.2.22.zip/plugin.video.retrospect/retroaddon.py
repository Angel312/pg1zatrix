# SPDX-License-Identifier: GPL-3.0-or-later

from resources.lib import addon
addon.run_addon()
