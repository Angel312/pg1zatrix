# SPDX-License-Identifier: GPL-3.0-or-later

import xbmc
xbmc.executebuiltin("Action(Queue)")
