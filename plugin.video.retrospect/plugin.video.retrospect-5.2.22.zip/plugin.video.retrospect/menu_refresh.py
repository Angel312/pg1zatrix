# SPDX-License-Identifier: GPL-3.0-or-later

import xbmc
xbmc.executebuiltin("Container.Refresh()")
