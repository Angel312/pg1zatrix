# SPDX-License-Identifier: CC-BY-NC-SA-4.0

import menu

with menu.Menu("Hide Channel") as m:
    m.hide_channel()
