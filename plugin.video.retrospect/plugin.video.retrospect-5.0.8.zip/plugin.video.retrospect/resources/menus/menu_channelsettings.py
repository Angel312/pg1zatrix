# SPDX-License-Identifier: CC-BY-NC-SA-4.0

import menu

with menu.Menu("Channel Settings") as m:
    m.channel_settings()
