import chn_class
import mediaitem

from logger import Logger
from regexer import Regexer
from urihandler import UriHandler
from parserdata import ParserData
from helpers.htmlentityhelper import HtmlEntityHelper
from helpers.jsonhelper import JsonHelper
from helpers.datehelper import DateHelper
from streams.m3u8 import M3u8


class Channel(chn_class.Channel):
    """
    main class from which all channels inherit
    """

    def __init__(self, channelInfo):
        """Initialisation of the class.

        Arguments:
        channelInfo: ChannelInfo - The channel info object to base this channel on.

        All class variables should be instantiated here and this method should not
        be overridden by any derived classes.

        """

        chn_class.Channel.__init__(self, channelInfo)

        # ==== Actual channel setup STARTS here and should be overwritten from derived classes =====
        self.noImage = "rtbfimage.png"

        # setup the urls
        self.mainListUri = "https://www.rtbf.be/auvio/emissions"
        self.baseUrl = "https://www.rtbf.be"
        # self.swfUrl = "http://www.canvas.be/sites/all/libraries/player/PolymediaShowFX16.swf"

        # setup the main parsing data
        episodeRegex = '<article[^>]+data-id="(?<id>(?<url>\d+))"[^>]*>\W+<figure[^>]+>\W+' \
                       '<figcaption[^>]+>(?<title>[^{][^<]+)</figcaption>\W*<div[^>]*>\W*' \
                       '<img[^>]*(?<thumburl>http[^"]+) \d+w"'
        episodeRegex = Regexer.from_expresso(episodeRegex)
        self._add_data_parser(self.mainListUri, match_type=ParserData.MatchExact,
                              preprocessor=self.AddCategoryAndLiveItems,
                              parser=episodeRegex,
                              creator=self.create_episode_item)

        self._add_data_parser("http://www.rtbf.be/news/api/menu?site=media", json=True,
                              match_type=ParserData.MatchExact,
                              parser=["item", 3, "item"], creator=self.CreateCategory)

        liveRegex = '<img[^>]*(?<thumburl>http[^"]+) \d+w"[^>]*>[\w\W]{0,1000}Maintenant</span> (?:sur )?(?<channel>[^>]+)</div>\W*<h3[^>]*>\W*<a[^>]+href="(?<url>[^"]+=(?<liveId>\d+))"[^>]+title="(?<title>[^"]+)'
        liveRegex = Regexer.from_expresso(liveRegex)
        self._add_data_parser("https://www.rtbf.be/auvio/direct/",
                              parser=liveRegex,
                              creator=self.create_video_item)

        self._add_data_parser("https://www.rtbf.be/auvio/embed/direct",
                              updater=self.UpdateLiveItem)

        videoRegex = '<img[^>]*(?<thumburl>http[^"]+) \d+w"[^>]*>[\w\W]{0,1000}?<time[^>]+' \
                     'datetime="(?<date>[^"]+)"[\w\W]{0,500}?<h4[^>]+>\W+<a[^>]+href="' \
                     '(?<url>[^<"]+=(?<videoId>\d+))"[^>]*>(?<title>[^<]+)</a>\W+</h4>\W+' \
                     '<h5[^>]+>(?<description>[^<]*)'
        videoRegex = Regexer.from_expresso(videoRegex)
        self._add_data_parser("*",
                              # preprocessor=self.ExtractVideoSection,
                              parser=videoRegex, creator=self.create_video_item,
                              updater=self.update_video_item)

        self.pageNavigationRegexIndex = 1
        pageRegex = '<li class="[^a][^"]+">\W+<a class="rtbf-pagination__link" href="([^"]+&p=)(\d+)"'
        self._add_data_parser("*",
                              # preprocessor=self.ExtractVideoSection,
                              parser=pageRegex, creator=self.create_page_item)

        self.swfUrl = "http://www.static.rtbf.be/rtbf/embed/js/vendor/jwplayer/jwplayer.flash.swf"
        # ==========================================================================================
        # Test cases:
        # 5@7

        # ====================================== Actual channel setup STOPS here ===================
        return

    def AddCategoryAndLiveItems(self, data):
        """Performs pre-process actions for data processing

        Arguments:
        data : string - the retrieve data that was loaded for the current item and URL.

        Returns:
        A tuple of the data and a list of MediaItems that were generated.


        Accepts an data from the process_folder_list method, BEFORE the items are
        processed. Allows setting of parameters (like title etc) for the channel.
        Inside this method the <data> could be changed and additional items can
        be created.

        The return values should always be instantiated in at least ("", []).

        """

        Logger.info("Performing Pre-Processing")
        items = []

        subItems = {
            "\a.: Direct :.": "%s/auvio/direct/" % (self.baseUrl, ),
            "\a.: Cat&eacute;gories :.": "http://www.rtbf.be/news/api/menu?site=media"
        }

        for k, v in subItems.iteritems():
            item = mediaitem.MediaItem(k, v)
            item.complete = True
            item.dontGroup = True
            items.append(item)
            item.isLive = v.endswith('/direct/')

        Logger.debug("Pre-Processing finished")
        return data, items

    def create_episode_item(self, resultSet):
        item = chn_class.Channel.create_episode_item(self, resultSet)
        if item is None:
            return item

        item.url = "%s/auvio/archives?pid=%s&contentType=complete" % (self.baseUrl, resultSet["id"])
        return item

    def CreateCategory(self, resultSet):
        resultSet = resultSet["@attributes"]
        Logger.trace(resultSet)
        # http://www.rtbf.be/auvio/archives?caid=29&contentType=complete,extract,bonus
        # {
        # u'url': u'http://www.rtbf.be/auvio/categorie/sport/football?id=11',
        # u'expandorder': u'6', u'aliases': u'football', u'id': u'category-11',
        # u'name': u'Football'
        # }
        cid = resultSet["id"].split("-")[-1]
        url = "%s/auvio/archives?caid=%s&contentType=complete,extract,bonus" % (self.baseUrl, cid)
        item = mediaitem.MediaItem(resultSet["name"], url)
        item.complete = True
        return item
    #
    # def CreateLiveChannelItem(self, resultSet):
    #     item = chn_class.Channel.create_episode_item(self, resultSet)
    #     if item is None:
    #         return item
    #
    #     item.url = "%s/auvio/archives?pid=%s&contentType=complete" % (self.baseUrl, resultSet["id"])
    #     return item

    def create_page_item(self, resultSet):
        item = chn_class.Channel.create_page_item(self, resultSet)
        url = "%s/auvio/archives%s%s" % (self.baseUrl, HtmlEntityHelper.url_decode(resultSet[0]), resultSet[1])
        item.url = url
        return item

    def create_video_item(self, resultSet):
        item = chn_class.Channel.create_video_item(self, resultSet)
        if item is None:
            return item

        # http://www.rtbf.be/auvio/embed/media?id=2101078&autoplay=1
        if "videoId" in resultSet:
            item.url = "%s/auvio/embed/media?id=%s" % (self.baseUrl, resultSet["videoId"])
        elif "liveId" in resultSet:
            item.name = "%s - %s" % (resultSet["channel"].strip(), item.name)
            item.url = "%s/auvio/embed/direct?id=%s" % (self.baseUrl, resultSet["liveId"])
            item.isLive = True

        if "date" in resultSet:
            # 2016-05-14T20:00:00+02:00 -> strip the hours
            timeStamp = DateHelper.get_date_from_string(resultSet["date"].rsplit("+")[0], "%Y-%m-%dT%H:%M:%S")
            item.set_date(*timeStamp[0:6])

        return item

    def update_video_item(self, item):
        data = UriHandler.open(item.url, proxy=self.proxy, additional_headers=item.HttpHeaders)
        mediaRegex = 'data-media="([^"]+)"'
        mediaInfo = Regexer.do_regex(mediaRegex, data)[0]
        mediaInfo = HtmlEntityHelper.convert_html_entities(mediaInfo)
        mediaInfo = JsonHelper(mediaInfo)
        Logger.trace(mediaInfo)

        # sources
        part = item.create_new_empty_media_part()
        # high, web, mobile, url
        mediaSources = mediaInfo.json.get("sources", {})
        for quality in mediaSources:
            url = mediaSources[quality]
            if quality == "high":
                bitrate = 2000
            elif quality == "web":
                bitrate = 800
            elif quality == "mobile":
                bitrate = 400
            else:
                bitrate = 0
            part.append_media_stream(url, bitrate)

        # geoLocRestriction
        item.isGeoLocked = not mediaInfo.get_value("geoLocRestriction", fallback="world") == "world"
        item.complete = True
        return item

    def UpdateLiveItem(self, item):
        data = UriHandler.open(item.url, proxy=self.proxy, additional_headers=item.HttpHeaders)
        mediaRegex = 'data-media="([^"]+)"'
        mediaInfo = Regexer.do_regex(mediaRegex, data)[0]
        mediaInfo = HtmlEntityHelper.convert_html_entities(mediaInfo)
        mediaInfo = JsonHelper(mediaInfo)
        Logger.trace(mediaInfo)
        part = item.create_new_empty_media_part()

        hlsUrl = mediaInfo.get_value("streamUrl")
        if hlsUrl is not None and "m3u8" in hlsUrl:
            Logger.debug("Found HLS url for %s: %s", mediaInfo.json["streamName"], hlsUrl)
            # from debug.router import Router
            # data = Router.get_via("be", hlsUrl, proxy=self.proxy)
            for s, b in M3u8.get_streams_from_m3u8(hlsUrl, self.proxy):
                part.append_media_stream(s, b)
                item.complete = True
        else:
            Logger.debug("No HLS url found for %s. Fetching RTMP Token.", mediaInfo.json["streamName"])
            # fetch the token:
            tokenUrl = "%s/api/media/streaming?streamname=%s" % (self.baseUrl, mediaInfo.json["streamName"])
            tokenData = UriHandler.open(tokenUrl, proxy=self.proxy, additional_headers=item.HttpHeaders, no_cache=True)
            tokenData = JsonHelper(tokenData)
            token = tokenData.get_value("token")
            Logger.debug("Found token '%s' for '%s'", token, mediaInfo.json["streamName"])

            rtmpUrl = "rtmp://rtmp.rtbf.be/livecast/%s?%s pageUrl=%s tcUrl=rtmp://rtmp.rtbf.be/livecast" % (mediaInfo.json["streamName"], token, self.baseUrl)
            rtmpUrl = self.get_verifiable_video_url(rtmpUrl)
            part.append_media_stream(rtmpUrl, 0)
            item.complete = True

        item.isGeoLocked = not mediaInfo.get_value("geoLocRestriction", fallback="world") == "world"
        return item
