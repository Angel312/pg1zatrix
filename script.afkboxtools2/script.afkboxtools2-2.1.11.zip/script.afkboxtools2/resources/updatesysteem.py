import xbmc, xbmcgui
import shutil
import urllib2,urllib
import time
import os

localtxt1 = 'Besturingssysteem Updaten van de AFK-Box (+/- 10min)'
localtxt2 = 'Moment geduld AUB!'
localtxt3 = 'Moment geduld AUB!'
localtxt4 = 'Moment geduld AUB!'


def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Updaten van de AFK-Box","Downloaden & uitpakken van het bestand. Even geduld a.u.b.",'')
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print 'Gedownload '+str(percent)+'%'
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled():
        print "DOWNLOAD GEANNULEERD" # need to get this part working
        dp.close()

class MyClass(xbmcgui.Window):
  def __init__(self):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("", localtxt1):
        url = 'http://backups.allefilmskijken.com/updatebestuurpack.zip'
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        lib=os.path.join(path, 'updatebestuurpack.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('storage/',''))
        xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))

 	xbmc.executebuiltin("Notification("+localtxt3+",AFK-Box Updater)")
 	xbmc.executebuiltin( "ActivateWindow(busydialog)" )
        time.sleep(10)
   	xbmc.executebuiltin("Notification("+localtxt2+",AFK-Box Updater)")
        time.sleep(10)
   	xbmc.executebuiltin("Notification("+localtxt2+",AFK-Box Updater)")
   	xbmc.executebuiltin('RunScript(special://home/addons/script.afkboxtools2/resources/afkboxscript.py,bestuurupdate60)')

mydisplay = MyClass()
del mydisplay