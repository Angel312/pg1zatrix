#-*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,sys
import shutil
import urllib2,urllib
import re
import extract
import time
import downloader
import plugintools
import zipfile
import ntpath

databasePath = xbmc.translatePath('special://database')
DBPATH = xbmc.translatePath('special://database')
TNPATH = xbmc.translatePath('special://thumbnails');
thumbnailPath = xbmc.translatePath('special://thumbnails');
thumbdir = xbmc.translatePath('special://thumbnails')
tempPath = xbmc.translatePath('special://temp')
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
base='http://www.allefilmskijken.com'
ADDON=xbmcaddon.Addon(id='script.afkboxtools2')
dialog = xbmcgui.Dialog()
VERSION = "1.0.0"
PATH = "afkbox"


def index():
    addDir('AFK Installer','',2,'http://addons.allefilmskijken.com/images/update.png','http://addons.allefilmskijken.com/images/achtergrond.png','')
    addDir('AFK Update','',3,'http://addons.allefilmskijken.com/images/update.png','http://addons.allefilmskijken.com/images/achtergrond.png','')
    addDir('AFK Bestuuringsysteem','',4,'http://addons.allefilmskijken.com/images/update.png','http://addons.allefilmskijken.com/images/achtergrond.png','')
    addDir('AFK Remote','',5,'http://addons.allefilmskijken.com/images/update.png','http://addons.allefilmskijken.com/images/achtergrond.png','')
    addDir('AFK Database','',7,'http://addons.allefilmskijken.com/images/update.png','http://addons.allefilmskijken.com/images/achtergrond.png','')
    addDir('AFK thumbnails','',9,'http://addons.allefilmskijken.com/images/update.png','http://addons.allefilmskijken.com/images/achtergrond.png','')
    setView('movies', 'MAIN')

def install():
    link = OPEN_URL('http://addons.allefilmskijken.com/updateafk2/install.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,6,iconimage,fanart,description, folder=False)
    setView('movies', 'MAIN')

def update():
    link = OPEN_URL('http://pastebin.com/raw/0DvmS9Dn').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,1,iconimage,fanart,description, folder=False)
    setView('movies', 'MAIN')

def bestuur():
    link = OPEN_URL('http://addons.allefilmskijken.com/updateafk2/bestuur.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,6,iconimage,fanart,description, folder=False)
    setView('movies', 'MAIN')

def remote():
    link = OPEN_URL('http://addons.allefilmskijken.com/update/remote.txt').replace('\n','').replace('\r','')
    match = re.compile('name="(.+?)".+?rl="(.+?)".+?mg="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall(link)
    for name,url,iconimage,fanart,description in match:
        addDir(name,url,6,iconimage,fanart,description, folder=False)
    setView('movies', 'MAIN')


def OPEN_URL(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link


def wizard(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib)
    if os.path.exists(lib):
        addonfolder = xbmc.translatePath(os.path.join('special://','home'))
        time.sleep(2)
        dp = xbmcgui.DialogProgress()
        dp.create("Uw systeem wordt nu bijgewerkt.",'', 'Wacht geduldig af tot volgende venster verschijnt.')
        dp.update(0,"", "ZIP wordt uitgepakt - even geduld")
        print '======================================='
        print addonfolder
        print '======================================='
        extract.all(lib,addonfolder,dp)
        dp.close()
        try: os.remove(lib)
        except: pass
        dialog = xbmcgui.Dialog()
        dialog.ok("AFK-Box Installer", "De AFK-Box moet worden herstart om de insallatie met succes af te ronden. Klik op OK deze te sluiten.")
        os._exit(1)

def wizardrem(name,url,description):
    path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
    lib=os.path.join(path, name+'.zip')
    try:
       os.remove(lib)
    except:
       pass
    downloader.download(url, lib)
    if os.path.exists(lib):
        addonfolder = xbmc.translatePath(os.path.join('/storage/'))
        time.sleep(2)
        dp = xbmcgui.DialogProgress()
        dp.create("Uw systeem wordt nu bijgewerkt.",'', 'Wacht geduldig af tot volgende venster verschijnt.')
        dp.update(0,"", "ZIP wordt uitgepakt - even geduld")
        print '======================================='
        print addonfolder
        print '======================================='
        extract.all(lib,addonfolder,dp)
        dp.close()
        try: os.remove(lib)
        except: pass
        dialog = xbmcgui.Dialog()
        dialog.ok("AFK-Box Installer", "De AFK-Box moet worden herstart om de insallatie met succes af te ronden. Klik op OK deze te herstarten.")
        xbmc.executebuiltin('Reboot')

def removeAddonsDatabase():
    dbList = os.listdir(databasePath)
    dbAddons = []
    removed = True
    for file in dbList:
        if re.findall('Addons(\d+)\.db', file):
            dbAddons.append(file)
    for file in dbAddons:
        dbFile = os.path.join(databasePath, file)
        try:
            os.unlink(dbFile)
        except:
            removed = False
    if removed:
        dialog.ok("AFK-Box Onderhoud", "Herstart uw systeem om addons database weer op te bouwen")
        xbmc.executebuiltin('Reboot')
    else:
        dialog.ok("AFK-Box Onderhoud", "Het verwijderen is mislukt!", "Probeer het na een herstart nog eens")


def deleteThumbnails():
    if os.path.exists(thumbnailPath)==True:
            if dialog.yesno("AFK-Box Onderhoud", "Deze optie verwijderd alle thumbnails", "Weet u zeker dat u deze wilt verwijderen?"):
                for root, dirs, files in os.walk(thumbnailPath):
                    file_count = 0
                    file_count += len(files)
                    if file_count > 0:
                        for f in files:
                            try:
                                os.unlink(os.path.join(root, f))
                            except:
                                pass
    else:
        pass

    text13 = os.path.join(databasePath,"Textures13.db")
    try:
        os.unlink(text13)
    except:
        try:
            dbcon = sqlite3.connect(text13)
            dbcur = dbcon.cursor()
            dbcur.execute('DROP TABLE IF EXISTS path')
            dbcur.execute('VACUUM')
            dbcon.commit()
            dbcur.execute('DROP TABLE IF EXISTS sizes')
            dbcur.execute('VACUUM')
            dbcon.commit()
            dbcur.execute('DROP TABLE IF EXISTS texture')
            dbcur.execute('VACUUM')
            dbcon.commit()
            dbcur.execute("""CREATE TABLE path (id integer, url text, type text, texture text, primary key(id))"""
                          )
            dbcon.commit()
            dbcur.execute("""CREATE TABLE sizes (idtexture integer,size integer, width integer, height integer, usecount integer, lastusetime text)"""
                          )
            dbcon.commit()
            dbcur.execute("""CREATE TABLE texture (id integer, url text, cachedurl text, imagehash text, lasthashcheck text, PRIMARY KEY(id))"""
                          )
            dbcon.commit()
        except:
            pass

    dialog.ok("AFK-Box Onderhoud", "Herstart uw systeem om de thumbnail map weer op te bouwen")
    xbmc.executebuiltin('Reboot')

def removefolder(map):
    if os.path.exists(map)==True:
        for root, dirs, files in os.walk(map, topdown=False):
            for name in files:
                try: os.remove(os.path.join(root, name))
                except: pass
            for name in dirs:
                try: os.rmdir(os.path.join(root, name))
                except: pass

def addDir(name,url,mode,iconimage,fanart,description,folder=True):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video", infoLabels={ "Title": name, "Plot": description } )
        liz.setProperty( "Fanart_Image", fanart )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=folder)
        return ok



def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]

        return param


params=get_params()
url=None
name=None
mode=None
iconimage=None
fanart=None
description=None


try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:
        description=urllib.unquote_plus(params["description"])
except:
        pass


print str(PATH)+': '+str(VERSION)
print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)
print "IconImage: "+str(iconimage)


def setView(content, viewType):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if ADDON.getSetting('auto-view')=='true':
        xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )


if mode==None:
    index()

elif mode==1:
    wizard(name,url,description)

elif mode==2:
    install()

elif mode==3:
    update()

elif mode==4:
    bestuur()

elif mode==5:
    remote()

elif mode==6:
    wizardrem(name,url,description)

elif mode==7:
    removeAddonsDatabase()

elif mode==9:
    deleteThumbnails()


xbmcplugin.endOfDirectory(int(sys.argv[1]))