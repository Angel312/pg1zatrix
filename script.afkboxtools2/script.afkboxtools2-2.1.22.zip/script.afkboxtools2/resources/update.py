import xbmc, xbmcgui
import shutil
import urllib2,urllib
import time
import os

localtxt1 = 'Updaten van de AFK-Box'
localtxt2 = 'Updaten voltooid! Herstarten AFK-Box'
localtxt3 = 'Update verwerken. Even geduld a.u.b.!'
localtxt4 = 'Update verwerken. Bijna klaar!'


def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Updaten van de AFK-Box","Downloaden & uitpakken van het bestand. Even geduld a.u.b.",'')
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print 'Gedownload '+str(percent)+'%'
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
    if dp.iscanceled():
        print "DOWNLOAD GEANNULEERD" # need to get this part working
        dp.close()

class MyClass(xbmcgui.Window):
  def __init__(self):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("", localtxt1):
        url = 'http://backups.allefilmskijken.com/updateafkii.zip'
        path = xbmc.translatePath(os.path.join('special://home/addons','packages'))
        lib=os.path.join(path, 'updateafkii.zip')
        DownloaderClass(url,lib)
        addonfolder = xbmc.translatePath(os.path.join('storage/',''))
        xbmc.executebuiltin("XBMC.Extract(%s,%s)"%(lib,addonfolder))

 	xbmc.executebuiltin("Notification("+localtxt3+",AFK-Box Updater)")
        time.sleep(10)
	xbmc.executebuiltin("Notification("+localtxt4+",AFK-Box Updater)")
        time.sleep(10)
   	xbmc.executebuiltin("Notification("+localtxt2+",AFK-Box Updater)")
        time.sleep(10)
   	xbmc.executebuiltin("Notification("+localtxt2+",AFK-Box Updater)")
   	xbmc.executebuiltin('RunScript(special://home/addons/script.afkboxtools2/resources/afkboxscript.py,update)')

mydisplay = MyClass()
del mydisplay