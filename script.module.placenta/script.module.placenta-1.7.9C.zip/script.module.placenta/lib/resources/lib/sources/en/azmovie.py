# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 12-31-2018 by JewBMX in Scrubs.
#Created by Tempest

import re
from resources.lib.modules import client,cleantitle,source_utils


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['azmovie.to']
        self.base_link = 'https://azmovie.to'
        self.search_link = '/watch.php?title=%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            title = cleantitle.geturl(title).replace('-', '+')
            url = self.base_link + self.search_link % title
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            r = client.request(url)
            u = client.parseDOM(r, "ul", attrs={"id": "serverul"})
            qual = re.compile('span class="quality.+?">(.+?)<').findall(r)
            for i in qual:
                if '1080p' in i:
                    quality = '1080p'
                elif '700p' in i:
                    quality = '720p'
                elif 'HD' in i:
                    quality = '720p'
                else:
                    quality = 'SD'
            for t in u:
                u = client.parseDOM(t, 'a', ret='href')
                for url in u:
                    if 'getlink' in url:
                        continue
                    valid, host = source_utils.is_host_valid(url, hostDict)
                    sources.append({'source': host, 'quality': quality, 'language': 'en', 'url': url, 'direct': False, 'debridonly': False})
                return sources
        except:
            return


    def resolve(self, url):
        return url

