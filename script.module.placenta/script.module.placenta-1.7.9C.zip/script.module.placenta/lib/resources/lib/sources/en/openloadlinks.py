# -*- coding: UTF-8 -*-
# -Cleaned and Checked on 12-03-2018 by JewBMX in Scrubs.

import re
from resources.lib.modules import cleantitle,client


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['en']
        self.domains = ['openloadlinks.com']
        self.base_link = 'http://www.openloadlinks.com'
        self.search_link = '/index.php?name=%s+%s'


    def movie(self, imdb, title, localtitle, aliases, year):
        try:
            title = cleantitle.geturl(title).replace('-', '+')
            url = self.base_link + self.search_link % (title, year)
            print url
            return url
        except:
            return


    def sources(self, url, hostDict, hostprDict):
        try:
            sources = []
            r = client.request(url)
            r = re.compile('href="(.+?//openload.co/f/.+?)"').findall(r)
            print
            for i in r:
                url = i.split('site=')[1]
                print url
                if '1080' in url:
                    quality = '1080p'
                elif 'BRRip' in url:
                    quality = '720p'
                elif 'HD' in url:
                    quality = '720p'
                elif '720p' in url:
                    quality = '720p'
                else:
                    quality = 'SD'
                sources.append({'source': 'openload', 'quality': quality, 'language': 'en', 'url': url, 'direct':False, 'debridonly': False})
            return sources
        except:
            return


    def resolve(self, url):
        return url

