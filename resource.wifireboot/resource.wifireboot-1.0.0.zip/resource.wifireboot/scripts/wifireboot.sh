#!/bin/sh
#kodi-send -a "Notification(script.sh:,'$1')"
#kodi-send -a "ReloadSkin()"

myInfo(){
  TIME=3000
  if [[ "$#" == 2 ]]; then
	TIME=$(($2*1000))
  fi

  kodi-send -a "Notification(Verwerken van Opdracht:,$1,$TIME )" &> /dev/null
  echo $1
}


if [[ "$1" == "wifi" ]]; then
     ifconfig wlan0 down
     sleep 1
     ifconfig wlan0 up
fi